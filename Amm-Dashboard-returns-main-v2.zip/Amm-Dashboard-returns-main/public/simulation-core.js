// simulation-core.js — AMM Volatility Harvesting Backtester v2
// Correct Uniswap-V3-style concentrated liquidity with:
//   • Fee-only profits (feeRate on swap notional, ALL to LP / pool owner)
//   • Dynamic concentration width driven by rolling correlation
//   • Dynamic recentering when price drifts outside the active range
//   • Volume-regime detection (LOW / MID / HIGH) for range width tuning

export function splitCsvLine(line) {
  const cells = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { current += '"'; i += 1; }
      else { quoted = !quoted; }
    } else if (char === ',' && !quoted) {
      cells.push(current); current = '';
    } else { current += char; }
  }
  cells.push(current);
  return cells;
}

export function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = splitCsvLine(lines[0]).map((v) => v.trim().toLowerCase());
  return lines.slice(1).map((line) => {
    const cells = splitCsvLine(line);
    return headers.reduce((row, h, i) => { row[h] = (cells[i] || '').trim(); return row; }, {});
  });
}

export function normalizeRows(rows) {
  return rows
    .map((row) => ({
      date: new Date(row.date),
      close: Number(row.close),
      volume: Number(row.volume),
    }))
    .filter((row) =>
      !Number.isNaN(row.date.getTime()) &&
      Number.isFinite(row.close) && row.close > 0 &&
      Number.isFinite(row.volume))
    .sort((a, b) => a.date - b.date);
}

// ─── Stats helpers ────────────────────────────────────────────────────────────

function mean(arr) {
  if (!arr.length) return 0;
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

function stdDev(arr, avg) {
  if (arr.length < 2) return 0;
  return Math.sqrt(arr.reduce((s, v) => s + (v - avg) ** 2, 0) / arr.length);
}

function pearsonCorr(a, b) {
  if (!a.length || a.length !== b.length) return 0;
  const ma = mean(a), mb = mean(b);
  let num = 0, va = 0, vb = 0;
  for (let i = 0; i < a.length; i += 1) {
    const da = a[i] - ma, db = b[i] - mb;
    num += da * db; va += da * da; vb += db * db;
  }
  const denom = Math.sqrt(va * vb);
  return denom > 0 ? num / denom : 0;
}

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

// ─── Merge 1-minute rows to hourly OHLCV ─────────────────────────────────────

function hourKey(date) {
  const d = new Date(date); d.setMinutes(0, 0, 0); return d.toISOString();
}

function mergeMinutely(a1, a2) {
  const merged = [];
  let i = 0, j = 0;
  while (i < a1.length && j < a2.length) {
    const t1 = a1[i].date.getTime(), t2 = a2[j].date.getTime();
    if (t1 === t2) { merged.push({ date: a1[i].date, c1: a1[i].close, c2: a2[j].close, v1: a1[i].volume, v2: a2[j].volume }); i++; j++; }
    else if (t1 < t2) { i++; } else { j++; }
  }
  return merged;
}

function toHourly(merged) {
  const map = new Map();
  for (const row of merged) {
    const key = hourKey(row.date);
    if (!map.has(key)) map.set(key, { date: new Date(key), c1: row.c1, c2: row.c2, vol: 0 });
    const b = map.get(key);
    b.c1 = row.c1; b.c2 = row.c2; b.vol += row.v1 + row.v2;
  }
  const arr = [...map.values()].sort((a, b) => a.date - b.date);
  for (let k = 0; k < arr.length; k++) {
    arr[k].ret1 = k === 0 ? 0 : (arr[k].c1 / arr[k - 1].c1) - 1;
    arr[k].ret2 = k === 0 ? 0 : (arr[k].c2 / arr[k - 1].c2) - 1;
  }
  return arr;
}

// ─── Volume regime ────────────────────────────────────────────────────────────

function volMode(vol, window, sigma) {
  if (!window.length) return 'MID';
  const avg = mean(window), sd = stdDev(window, avg), band = sigma * sd;
  if (vol < avg - band) return 'LOW';
  if (vol > avg + band) return 'HIGH';
  return 'MID';
}

// ─── Uniswap V3 concentrated liquidity math ───────────────────────────────────
//
// Price p = asset1_price / asset2_price  (units: asset2 per 1 asset1)
// Range  [pa, pb] around center.
//
// Given liquidity L:
//   x (asset1 units) = L * (1/sqrt(p) − 1/sqrt(pb))
//   y (asset2 units) = L * (sqrt(p)   − sqrt(pa))
//
// Derive L from real capital at initial price:

function amountsFromL(L, p, pa, pb) {
  const sp = Math.sqrt(p), spa = Math.sqrt(pa), spb = Math.sqrt(pb);
  if (p <= pa) return { x: L * (1 / spa - 1 / spb), y: 0 };
  if (p >= pb) return { x: 0, y: L * (spb - spa) };
  return { x: L * (1 / sp - 1 / spb), y: L * (sp - spa) };
}

function liquidityFromAmounts(x, y, p, pa, pb) {
  const sp = Math.sqrt(p), spa = Math.sqrt(pa), spb = Math.sqrt(pb);
  const lx = (1 / sp - 1 / spb) > 1e-12 ? x / (1 / sp - 1 / spb) : Infinity;
  const ly = (sp - spa) > 1e-12 ? y / (sp - spa) : Infinity;
  return Math.min(lx, ly);
}

// ─── Main simulation ──────────────────────────────────────────────────────────

export function runAlmSimulation(df1, df2, realCapital, config = {}) {
  const asset1 = normalizeRows(df1);
  const asset2 = normalizeRows(df2);

  if (!asset1.length || !asset2.length)
    return { error: 'Both CSV files must include valid date, close, and volume columns.' };

  const merged = mergeMinutely(asset1, asset2);
  if (!merged.length)
    return { error: 'No overlapping timestamps found in the two datasets. Check that both CSVs cover the same period.' };

  const hourly = toHourly(merged);
  if (hourly.length < 2)
    return { error: 'Need at least two hourly buckets after preprocessing.' };

  // ── Config ─────────────────────────────────────────────────────────────────
  const lowW       = clamp(Number(config.lowWidth  ?? 0.75), 0.05, 50) / 100;
  const midW       = clamp(Number(config.midWidth  ?? 2),    0.05, 50) / 100;
  const highW      = clamp(Number(config.highWidth ?? 5),    0.05, 50) / 100;
  const sigmaT     = Number(config.sigmaThreshold     ?? 1);
  const lookbackH  = Math.max(2, Number(config.lookbackHours     ?? 24));
  const corrLB     = Math.max(2, Number(config.corrLookbackHours ?? 24));
  const corrImpact = clamp(Number(config.correlationImpact ?? 0.6), 0, 2);
  const recTrigF   = clamp(Number(config.recenterTriggerPct ?? 75) / 100, 0.05, 2);
  const feeRate    = clamp(Number(config.feePct ?? 0.3), 0, 10) / 100;
  const pauseHigh  = Boolean(config.pauseHighVol ?? false);

  // ── Initialise pool ─────────────────────────────────────────────────────────
  const h0 = hourly[0];
  // Price ratio: how many units of asset2 per 1 unit of asset1
  let centerP = h0.c1 / h0.c2;
  let rangeHalf = midW;
  let pa = centerP * (1 - rangeHalf);
  let pb = centerP * (1 + rangeHalf);

  // 50/50 capital split by value
  const halfCap = realCapital / 2;
  const xInit = halfCap / h0.c1;  // asset1 units
  const yInit = halfCap / h0.c2;  // asset2 units

  // Derive liquidity L from initial holdings within initial range
  let L = liquidityFromAmounts(xInit, yInit, centerP, pa, pb);

  let prevX = xInit, prevY = yInit;
  let accFees = 0;
  let recenterCount = 0;
  let currentMode = 'MID';
  const modeHours = { LOW: 0, MID: 0, HIGH: 0 };

  const swapRecords = [];
  const equityCurve = [];

  const initCapital = xInit * h0.c1 + yInit * h0.c2;
  equityCurve.push({ date: h0.date.toISOString(), poolValue: initCapital, holdValue: initCapital, feesAccum: 0, correlation: 0, dynamicWidthPct: rangeHalf * 100, mode: 'MID' });

  for (let idx = 1; idx < hourly.length; idx++) {
    const row = hourly[idx];
    const p   = row.c1 / row.c2;  // current price ratio

    // 1. Volume regime
    const volWin = hourly.slice(Math.max(0, idx - lookbackH), idx).map((h) => h.vol);
    currentMode = volMode(row.vol, volWin, sigmaT);
    modeHours[currentMode] += 1;

    // 2. Rolling correlation (of 1-hour returns)
    const corrWin = hourly.slice(Math.max(0, idx - corrLB), idx);
    const corr = pearsonCorr(corrWin.map((h) => h.ret1), corrWin.map((h) => h.ret2));

    // 3. Dynamic width
    //    Low correlation → assets diverge → widen range to keep both in range
    //    High correlation → assets move together → tighten for capital efficiency
    const baseW = currentMode === 'LOW' ? lowW : currentMode === 'HIGH' ? highW : midW;
    const dynW  = clamp(baseW * (1 + corrImpact * (1 - Math.abs(corr))), lowW * 0.4, highW * 3);

    // 4. Recentering
    const drift = Math.abs(p / centerP - 1);
    const recThresh = dynW * recTrigF;
    const needsRecenter = drift >= recThresh;
    let recentered = false;

    if (needsRecenter && !(pauseHigh && currentMode === 'HIGH')) {
      // Snapshot current amounts at current price (clamped to old range)
      const snap = amountsFromL(L, clamp(p, pa, pb), pa, pb);
      prevX = snap.x; prevY = snap.y;

      // Reset center and range
      centerP = p;
      rangeHalf = dynW;
      pa = centerP * (1 - rangeHalf);
      pb = centerP * (1 + rangeHalf);

      // Recompute L from current holdings within new range
      L = liquidityFromAmounts(prevX, prevY, centerP, pa, pb);
      recenterCount++;
      recentered = true;
    } else {
      // Just update range width, keep center
      rangeHalf = dynW;
      pa = centerP * (1 - rangeHalf);
      pb = centerP * (1 + rangeHalf);
    }

    // 5. AMM position at current price
    const pC = clamp(p, pa, pb);
    const { x: newX, y: newY } = amountsFromL(L, pC, pa, pb);

    // 6. Fee = feeRate × notional of rebalancing swap (ALL goes to LP/pool owner)
    const dx = Math.abs(newX - prevX);
    const dy = Math.abs(newY - prevY);
    const notional = dx * row.c1 + dy * row.c2;
    const feeEarned = notional * feeRate;

    let action = 'Hold (no rebalance)';
    if (newX > prevX + 1e-9) action = 'Buy Asset 1 / Sell Asset 2';
    else if (newX < prevX - 1e-9) action = 'Sell Asset 1 / Buy Asset 2';

    if (notional > 1e-6) {
      accFees += feeEarned;
      swapRecords.push({
        date: row.date.toISOString(),
        mode: currentMode,
        rollingCorrelation: corr,
        dynamicWidthPct: dynW * 100,
        recentered,
        action,
        centerRatio: centerP,
        priceRatio: p,
        asset1Price: row.c1,
        asset2Price: row.c2,
        asset1Units: newX,
        asset2Units: newY,
        dx,
        dy,
        notionalINR: notional,
        feeEarned,
        accumulatedFees: accFees,
        poolValueINR: newX * row.c1 + newY * row.c2 + accFees,
      });
    }

    prevX = newX; prevY = newY;

    // 7. Equity curve
    const poolAssets = newX * row.c1 + newY * row.c2;
    const holdValue  = xInit * row.c1 + yInit * row.c2;
    equityCurve.push({
      date: row.date.toISOString(),
      poolValue: poolAssets + accFees,
      holdValue,
      feesAccum: accFees,
      correlation: corr,
      dynamicWidthPct: dynW * 100,
      mode: currentMode,
    });
  }

  // ── Final metrics ───────────────────────────────────────────────────────────
  const last       = hourly[hourly.length - 1];
  const holdValue  = xInit * last.c1 + yInit * last.c2;
  const poolAssets = prevX * last.c1 + prevY * last.c2;
  const totalValue = poolAssets + accFees;
  const ilINR      = poolAssets - holdValue;
  const ilPct      = holdValue > 0 ? (poolAssets / holdValue - 1) * 100 : 0;
  const roiPct     = initCapital > 0 ? ((totalValue / initCapital) - 1) * 100 : 0;
  const holdRoiPct = initCapital > 0 ? ((holdValue  / initCapital) - 1) * 100 : 0;
  const feeRoiPct  = initCapital > 0 ? (accFees     / initCapital)      * 100 : 0;

  return {
    swaps: swapRecords,
    equityCurve,
    results: {
      totalSwaps: swapRecords.length,
      accumulatedFees: accFees,
      holdValue,
      poolAssets,
      totalValue,
      ilINR,
      ilPct,
      roiPct,
      holdRoiPct,
      feeRoiPct,
      initCapital,
      initialX: xInit,
      initialY: yInit,
      finalX: prevX,
      finalY: prevY,
      lowModeHours:  modeHours.LOW,
      midModeHours:  modeHours.MID,
      highModeHours: modeHours.HIGH,
      recenterCount,
      feePct: feeRate * 100,
    },
  };
}
