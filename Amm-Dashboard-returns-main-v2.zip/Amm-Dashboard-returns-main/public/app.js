import { parseCsv, runAlmSimulation } from './simulation-core.js';

// ─── State ────────────────────────────────────────────────────────────────────
const state = { swaps: [], results: null, equity: [] };

// ─── DOM refs ─────────────────────────────────────────────────────────────────
const asset1File          = document.getElementById('asset1File');
const asset2File          = document.getElementById('asset2File');
const asset1FileName      = document.getElementById('asset1FileName');
const asset2FileName      = document.getElementById('asset2FileName');
const asset1Label         = document.getElementById('asset1Label');
const asset2Label         = document.getElementById('asset2Label');
const realCapitalInput    = document.getElementById('realCapital');
const feePctInput         = document.getElementById('feePct');
const lowWidthInput       = document.getElementById('lowWidth');
const midWidthInput       = document.getElementById('midWidth');
const highWidthInput      = document.getElementById('highWidth');
const sigmaThresholdInput = document.getElementById('sigmaThreshold');
const lookbackHoursInput  = document.getElementById('lookbackHours');
const corrLookbackInput   = document.getElementById('corrLookbackHours');
const corrImpactInput     = document.getElementById('correlationImpact');
const recenterTrigInput   = document.getElementById('recenterTriggerPct');
const pauseHighVolInput   = document.getElementById('pauseHighVol');
const runBtn              = document.getElementById('runSimulation');
const statusBanner        = document.getElementById('statusBanner');
const metricsGrid         = document.getElementById('metricsGrid');
const swapTableContainer  = document.getElementById('swapTableContainer');
const downloadCsvBtn      = document.getElementById('downloadCsv');
const swapCount           = document.getElementById('swapCount');
const pairHeading         = document.getElementById('pairHeading');
const chartCanvas         = document.getElementById('equityChart');
const corrChartCanvas     = document.getElementById('corrChart');

// ─── Formatters ───────────────────────────────────────────────────────────────
const inr  = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const pct  = (v, d = 2) => `${v >= 0 ? '+' : ''}${v.toFixed(d)}%`;
const num  = (d = 2) => new Intl.NumberFormat('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });

// ─── Event listeners ──────────────────────────────────────────────────────────
asset1File.addEventListener('change', () => { asset1FileName.textContent = asset1File.files[0]?.name || 'Upload Asset 1 CSV'; });
asset2File.addEventListener('change', () => { asset2FileName.textContent = asset2File.files[0]?.name || 'Upload Asset 2 CSV'; });
asset1Label.addEventListener('input', updatePairHeading);
asset2Label.addEventListener('input', updatePairHeading);
downloadCsvBtn.addEventListener('click', () => downloadCsv(state.swaps));
runBtn.addEventListener('click', handleRunSimulation);
updatePairHeading();

function updatePairHeading() {
  pairHeading.textContent = `${asset1Label.value || 'Asset 1'} ↔ ${asset2Label.value || 'Asset 2'}`;
}

function setStatus(type, message) {
  statusBanner.className = `status-banner ${type}`;
  statusBanner.innerHTML = `<strong>${type.toUpperCase()}:</strong> <span>${message}</span>`;
}

function getConfig() {
  return {
    feePct:              Number(feePctInput.value),
    lowWidth:            Number(lowWidthInput.value),
    midWidth:            Number(midWidthInput.value),
    highWidth:           Number(highWidthInput.value),
    sigmaThreshold:      Number(sigmaThresholdInput.value),
    lookbackHours:       Number(lookbackHoursInput.value),
    corrLookbackHours:   Number(corrLookbackInput.value),
    correlationImpact:   Number(corrImpactInput.value),
    recenterTriggerPct:  Number(recenterTrigInput.value),
    pauseHighVol:        pauseHighVolInput.checked,
  };
}

// ─── Run simulation ───────────────────────────────────────────────────────────
async function handleRunSimulation() {
  if (!asset1File.files[0] || !asset2File.files[0]) {
    setStatus('error', 'Please upload both CSV files before running the simulation.');
    return;
  }
  runBtn.disabled = true;
  runBtn.textContent = 'Running…';
  setStatus('info', 'Merging 1-minute data → hourly buckets → concentrated liquidity AMM…');

  try {
    await new Promise((r) => setTimeout(r, 10)); // let UI update
    const [t1, t2] = await Promise.all([asset1File.files[0].text(), asset2File.files[0].text()]);
    const result = runAlmSimulation(parseCsv(t1), parseCsv(t2), Number(realCapitalInput.value), getConfig());

    if (result.error) {
      state.swaps = []; state.results = null; state.equity = [];
      renderMetrics(); renderTable(); destroyCharts();
      setStatus('error', result.error);
    } else {
      state.swaps   = result.swaps;
      state.results = result.results;
      state.equity  = result.equityCurve;
      renderMetrics();
      renderTable();
      renderCharts();
      const r = result.results;
      if (r.totalValue > r.holdValue) {
        setStatus('success', `AMM outperformed buy-and-hold by ${inr.format(r.totalValue - r.holdValue)} (fees: ${inr.format(r.accumulatedFees)}, IL: ${inr.format(r.ilINR)}).`);
      } else {
        setStatus('warning', `Underperformed hold by ${inr.format(r.holdValue - r.totalValue)}. IL (${r.ilPct.toFixed(2)}%) ate into fee income (${inr.format(r.accumulatedFees)}). Try wider ranges or lower fee.`);
      }
    }
  } catch (err) {
    setStatus('error', err.message || 'Unable to parse one of the uploaded CSV files.');
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = 'Run Simulation';
  }
}

// ─── Metrics grid ─────────────────────────────────────────────────────────────
function renderMetrics() {
  if (!state.results) {
    metricsGrid.innerHTML = `<div class="empty-state"><h3>No results yet</h3><p>Upload two 1-minute CSV files and run the simulation.</p></div>`;
    downloadCsvBtn.classList.add('hidden');
    return;
  }
  const r = state.results;
  const a1 = asset1Label.value || 'Asset 1';
  const a2 = asset2Label.value || 'Asset 2';

  const cards = [
    { label: 'Initial Capital',        value: inr.format(r.initCapital),       delta: null },
    { label: 'Total AMM Value',        value: inr.format(r.totalValue),        delta: pct(r.roiPct),     positive: r.roiPct >= 0 },
    { label: 'Buy-and-Hold Value',     value: inr.format(r.holdValue),         delta: pct(r.holdRoiPct), positive: r.holdRoiPct >= 0 },
    { label: 'Fee Income (LP Reward)', value: inr.format(r.accumulatedFees),   delta: pct(r.feeRoiPct),  positive: true },
    { label: 'Pool Assets Value',      value: inr.format(r.poolAssets),        delta: null },
    { label: 'Impermanent Loss',       value: inr.format(r.ilINR),             delta: pct(r.ilPct),      positive: r.ilPct >= 0 },
    { label: 'Total Rebalances',       value: num(0).format(r.totalSwaps),     delta: null },
    { label: 'Recenter Count',         value: num(0).format(r.recenterCount),  delta: null },
    { label: `Initial ${a1} Units`,    value: num(4).format(r.initialX),       delta: null },
    { label: `Initial ${a2} Units`,    value: num(4).format(r.initialY),       delta: null },
    { label: `Final ${a1} Units`,      value: num(4).format(r.finalX),         delta: null },
    { label: `Final ${a2} Units`,      value: num(4).format(r.finalY),         delta: null },
    { label: 'Mode Hours L / M / H',   value: `${r.lowModeHours} / ${r.midModeHours} / ${r.highModeHours}`, delta: null },
    { label: 'Fee Rate',               value: `${r.feePct.toFixed(2)}%`,       delta: null },
  ];

  metricsGrid.innerHTML = cards.map(({ label, value, delta, positive }) => `
    <div class="metric-card">
      <span>${label}</span>
      <strong>${value}</strong>
      ${delta ? `<em class="${positive ? 'positive' : 'negative'}">${delta}</em>` : ''}
    </div>`).join('');

  downloadCsvBtn.classList.remove('hidden');
}

// ─── Equity & Correlation Charts (vanilla Canvas) ─────────────────────────────
let charts = [];

function destroyCharts() {
  charts.forEach((c) => c.destroy?.());
  charts = [];
}

function renderCharts() {
  destroyCharts();
  if (!state.equity.length) return;

  // Sample for performance (max 400 points)
  const data = state.equity;
  const step = Math.max(1, Math.floor(data.length / 400));
  const sampled = data.filter((_, i) => i % step === 0);

  drawLineChart(chartCanvas, sampled, [
    { key: 'poolValue', label: 'AMM Pool Value', color: '#38bdf8' },
    { key: 'holdValue', label: 'Buy & Hold Value', color: '#818cf8' },
    { key: 'feesAccum', label: 'Accumulated Fees', color: '#22c55e' },
  ], 'INR (₹)');

  drawLineChart(corrChartCanvas, sampled, [
    { key: 'correlation', label: 'Rolling Correlation', color: '#f97316' },
    { key: 'dynamicWidthPct', label: 'Dynamic Width %', color: '#a78bfa', scale: 1 / 100 },
  ], 'Correlation / Width');
}

function drawLineChart(canvas, data, series, yLabel) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width  = rect.width  * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  const W = rect.width, H = rect.height;
  const PAD = { top: 24, right: 16, bottom: 48, left: 80 };
  const cW = W - PAD.left - PAD.right;
  const cH = H - PAD.top - PAD.bottom;

  ctx.clearRect(0, 0, W, H);

  // Find global min/max across all series (with optional scale)
  let yMin = Infinity, yMax = -Infinity;
  for (const s of series) {
    const sc = s.scale ?? 1;
    for (const d of data) {
      const v = d[s.key] * sc;
      if (v < yMin) yMin = v;
      if (v > yMax) yMax = v;
    }
  }
  if (yMin === yMax) { yMin -= 1; yMax += 1; }
  const yRange = yMax - yMin;

  const toX = (i) => PAD.left + (i / (data.length - 1)) * cW;
  const toY = (v) => PAD.top + cH - ((v - yMin) / yRange) * cH;

  // Grid lines
  ctx.strokeStyle = 'rgba(148,163,184,0.12)';
  ctx.lineWidth = 1;
  const gridLines = 5;
  for (let g = 0; g <= gridLines; g++) {
    const yv = yMin + (g / gridLines) * yRange;
    const yp = toY(yv);
    ctx.beginPath(); ctx.moveTo(PAD.left, yp); ctx.lineTo(PAD.left + cW, yp); ctx.stroke();
    ctx.fillStyle = 'rgba(148,163,184,0.7)';
    ctx.font = '10px Arial';
    ctx.textAlign = 'right';
    const label = yRange > 1000 ? `₹${(yv / 1e5).toFixed(1)}L` : yv.toFixed(3);
    ctx.fillText(label, PAD.left - 6, yp + 4);
  }

  // X labels (dates)
  const xSteps = Math.min(6, data.length);
  for (let s = 0; s <= xSteps; s++) {
    const i = Math.round((s / xSteps) * (data.length - 1));
    const xp = toX(i);
    const d = new Date(data[i].date);
    ctx.fillStyle = 'rgba(148,163,184,0.7)';
    ctx.font = '10px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }), xp, H - PAD.bottom + 16);
  }

  // Y label
  ctx.save();
  ctx.translate(14, PAD.top + cH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillStyle = 'rgba(148,163,184,0.7)';
  ctx.font = '11px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(yLabel, 0, 0);
  ctx.restore();

  // Series lines
  for (const s of series) {
    const sc = s.scale ?? 1;
    ctx.beginPath();
    ctx.strokeStyle = s.color;
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    data.forEach((d, i) => {
      const x = toX(i), y = toY(d[s.key] * sc);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  // Legend
  let lx = PAD.left;
  series.forEach((s) => {
    ctx.fillStyle = s.color;
    ctx.fillRect(lx, 6, 16, 3);
    ctx.fillStyle = 'rgba(148,163,184,0.9)';
    ctx.font = '11px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(s.label, lx + 20, 13);
    lx += ctx.measureText(s.label).width + 44;
  });
}

// ─── Swap table ───────────────────────────────────────────────────────────────
function renderTable() {
  if (!state.swaps.length) {
    swapCount.classList.add('hidden');
    swapTableContainer.innerHTML = `<div class="empty-state compact"><h3>No rebalances recorded</h3><p>Adjust range widths and run again.</p></div>`;
    return;
  }
  const a1 = asset1Label.value || 'Asset 1';
  const a2 = asset2Label.value || 'Asset 2';
  swapCount.textContent = `${state.swaps.length} rebalances`;
  swapCount.classList.remove('hidden');

  // Show latest 500 rows to keep DOM manageable
  const rows = state.swaps.slice(-500);
  const note = state.swaps.length > 500 ? `<p class="table-note">Showing last 500 of ${state.swaps.length} rebalances. Download CSV for full history.</p>` : '';

  swapTableContainer.innerHTML = note + `
    <div class="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Date</th><th>Mode</th><th>Correlation</th><th>Dyn.Width%</th>
            <th>Recentered</th><th>Action</th>
            <th>${a1} Price</th><th>${a2} Price</th>
            <th>Δ${a1}</th><th>Δ${a2}</th>
            <th>Notional</th><th>Fee Earned</th><th>Accum.Fees</th>
            <th>${a1} Units</th><th>${a2} Units</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((s) => `
            <tr class="${s.recentered ? 'recenter-row' : ''}">
              <td>${new Date(s.date).toLocaleString('en-IN')}</td>
              <td><span class="mode-pill mode-${s.mode.toLowerCase()}">${s.mode}</span></td>
              <td>${s.rollingCorrelation.toFixed(3)}</td>
              <td>${s.dynamicWidthPct.toFixed(2)}%</td>
              <td>${s.recentered ? '<span class="pill-sm">↺</span>' : '—'}</td>
              <td>${s.action}</td>
              <td>${inr.format(s.asset1Price)}</td>
              <td>${inr.format(s.asset2Price)}</td>
              <td>${num(4).format(s.dx)}</td>
              <td>${num(4).format(s.dy)}</td>
              <td>${inr.format(s.notionalINR)}</td>
              <td class="positive">${inr.format(s.feeEarned)}</td>
              <td>${inr.format(s.accumulatedFees)}</td>
              <td>${num(4).format(s.asset1Units)}</td>
              <td>${num(4).format(s.asset2Units)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

// ─── Download CSV ─────────────────────────────────────────────────────────────
function downloadCsv(rows) {
  const headers = [
    'Date','Mode','Rolling_Correlation','Dynamic_Width_Pct','Recentered','Action',
    'Asset1_Price','Asset2_Price','Delta_Asset1','Delta_Asset2',
    'Notional_INR','Fee_Earned_INR','Accumulated_Fees_INR',
    'Asset1_Units','Asset2_Units','Pool_Value_INR',
  ];
  const lines = [headers.join(',')].concat(rows.map((r) => [
    r.date, r.mode, r.rollingCorrelation.toFixed(6), r.dynamicWidthPct.toFixed(4),
    r.recentered, r.action,
    r.asset1Price, r.asset2Price, r.dx.toFixed(6), r.dy.toFixed(6),
    r.notionalINR.toFixed(2), r.feeEarned.toFixed(2), r.accumulatedFees.toFixed(2),
    r.asset1Units.toFixed(6), r.asset2Units.toFixed(6), r.poolValueINR.toFixed(2),
  ].join(',')));
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'alm_rebalances.csv'; a.click();
  URL.revokeObjectURL(url);
}
